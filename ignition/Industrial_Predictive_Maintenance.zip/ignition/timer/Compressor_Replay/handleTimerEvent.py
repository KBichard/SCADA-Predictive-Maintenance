def handleTimerEvent():

    base = "[default]Compressor_01/"

    def write_tags(values):
        names = list(values.keys())

        results = system.tag.writeBlocking(
            [base + name for name in names],
            [values[name] for name in names]
        )

        if not all(q.isGood() for q in results):
            raise Exception("Tag write failed")

    try:

        enabled, index = system.tag.readBlocking([
            base + "Replay_Enabled",
            base + "Replay_Index"
        ])

        if not enabled.value:
            return

        path = r"C:\SCADA-Predictive-Maintenance\data\scada_replay.json"

        records = system.util.jsonDecode(
            system.file.readFileAsString(path)
        )

        i = int(index.value)

        if i >= len(records):

            write_tags({
                "Replay_Enabled": False,
                "Alarm_Status": "REPLAY COMPLETE",
                "Model_Ready": False,
                "Sensor_Ready": False,
                "Urgent_Alarm": False,
                "Anomaly_Score": -1.0
            })

            return

        row = records[i]

        values = {
            "Replay_Timestamp": row["timestamp"],
            "Alarm_Status": row["alarm_status"],
            "Sensor_Ready": row["sensor_ready"],
            "Model_Ready": row["model_ready"],
            "Urgent_Alarm": row["urgent_alarm"]
        }

        if row["sensor_ready"]:

            values.update({
                "Motor_Current": row["motor_current"],
                "Oil_Temperature": row["oil_temperature"],
                "TP2": row["tp2"],
                "TP3": row["tp3"],
                "H1": row["h1"],
                "DV_Pressure": row["dv_pressure"],
                "Reservoir_Pressure": row["reservoir_pressure"],
                "Motor_Running": row["motor_current"] > 1.0,
                "Sensor_Timestamp": row["sensor_timestamp"]
            })

        if row["model_ready"]:
            values["Anomaly_Score"] = row["isolation_forest_score"]
        else:
            values["Anomaly_Score"] = -1.0

        write_tags(values)

        write_tags({"Replay_Index": i + 1})

    except Exception as error:

        system.util.getLogger("CompressorReplay").error(
            str(error)
        )

        write_tags({
            "Replay_Enabled": False,
            "Alarm_Status": "REPLAY ERROR",
            "Model_Ready": False,
            "Sensor_Ready": False,
            "Urgent_Alarm": False,
            "Anomaly_Score": -1.0
        })